import tkinter as tk
from tkinter import messagebox
# Configuration
COLORS = {1: "red", 2: "blue", 3: "green", 4: "yellow", 5: "purple", 6: "pink", 7: "gray"}
GRID_MAP = [
    [1, 2, 7],
    [3, 4, 6],
    [5, 7, 1],
    [2, 3, 5]
]

class PaintByNumber:
    def __init__(self, root):
        self.root = root
        self.root.title("Python Color by Numbers 2026")
        self.buttons = []
        
        for r, row in enumerate(GRID_MAP):
            button_row = []
            for c, num in enumerate(row):
                btn = tk.Button(root, text=str(num), width=10, height=4,
                               command=lambda r=r, c=c: self.color_cell(r, c))
                btn.grid(row=r, column=c)
                button_row.append(btn)
            self.buttons.append(button_row)

    def color_cell(self, r, c):
        correct_num = GRID_MAP[r][c]
        # In a real app, you could add an entry box to let the user pick a number
        self.buttons[r][c].config(bg=COLORS[correct_num], text="")

if __name__ == "__main__":
    root = tk.Tk()
    app = PaintByNumber(root)
    root.mainloop()
