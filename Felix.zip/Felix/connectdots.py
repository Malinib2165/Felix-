class DotsAndBoxes:
   def __init__(self, size):
       self.size = size
       self.board = [[0] * (size + 1) for _ in range(size + 1)]
       self.scores = [0, 0]
       self.current_player = 0
   def draw_line(self, x1, y1, x2, y2):
       if abs(x1 - x2) + abs(y1 - y2) != 1 or self.board[x1][y1] or self.board[x2][y2]:
           print("Invalid move!")
           return False
       self.board[x1][y1] = self.board[x2][y2] = 1
       if not self.check_box_completion(x1, y1, x2, y2):
           self.current_player = 1 - self.current_player
       return True
   def check_box_completion(self, x1, y1, x2, y2):
       completed = False
       for dx, dy in [(0, 1), (1, 0)]:
           if all(self.board[x + dx][y + dy] for x, y in [(x1, y1), (x2, y2)]):
               self.scores[self.current_player] += 1
               completed = True
       return completed
   def display_scores(self):
       print(f"Player 1: {self.scores[0]}, Player 2: {self.scores[1]}")
# Example usage
game = DotsAndBoxes(3)
game.draw_line(0, 0, 0, 1)
game.display_scores()