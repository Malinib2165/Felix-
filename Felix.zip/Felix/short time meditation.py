import time
import sys

def meditate(minutes=1):
    phases = [
        ("Inhale...", 5),
        ("Hold...", 4),
        ("Exhale...", 4),
        ("Hold...", 4)
    ]
    
    end_time = time.time() + (minutes * 60)
    print(f"--- Starting {minutes}-minute short-term meditation ---")
    
    try:
        while time.time() < end_time:
            for message, duration in phases:
                for i in range(duration, 0, -1):
                    # Clears the line and updates the countdown
                    sys.stdout.write(f"\r{message} [{i}]   ")
                    sys.stdout.flush()
                    time.sleep(1)
        print("\n--- Session Complete. Stay mindful! ---")
    except KeyboardInterrupt:
        print("\n--- Session Ended Early ---")

if __name__ == "__main__":
    meditate(1)  # Set duration in minutes
